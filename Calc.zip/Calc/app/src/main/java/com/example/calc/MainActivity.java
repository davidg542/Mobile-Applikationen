package com.example.calc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    TextView inputText, outputText;
    private String input, output, result;
    private Button zeroButton, oneButton, twoButton, threeButton, fourButton, fiveButton,
    sixButton, sevenButton, eightButton, nineButton, equalsButton, hochButton, clearButton, prozentButton,
    geteiltButton, mulButton, minButton, plusButton, pointButton;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputText);
        outputText = findViewById(R.id.outputText);

        zeroButton = findViewById(R.id.zeroButton);
        oneButton = findViewById(R.id.oneButton);
        twoButton = findViewById(R.id.twoButton);
        threeButton = findViewById(R.id.threeButton);
        fourButton = findViewById(R.id.fourButton);
        fiveButton = findViewById(R.id.fiveButton);
        sixButton = findViewById(R.id.sixButton);
        sevenButton = findViewById(R.id.sevenButton);
        eightButton = findViewById(R.id.eightButton);
        nineButton = findViewById(R.id.nineButton);
        equalsButton = findViewById(R.id.equalsButton);
        hochButton = findViewById(R.id.hochButton);
        clearButton = findViewById(R.id.clearButton);

        geteiltButton = findViewById(R.id.geteiltButton);
        mulButton = findViewById(R.id.mulButton);
        minButton = findViewById(R.id.minButton);
        plusButton = findViewById(R.id.plusButton);
        pointButton = findViewById(R.id.pointButton);


    }

    public void onButtonClicked (View view){

        Button button = (Button) view;
        String data = button.getText().toString();
        switch(data){
            case "C":
                input = null;
                output = null;
                result = null;
                outputText.setText("");
                break;

            case "^":
                solve();
                input+="^";
                break;
            case "*":
                solve();
                input+="*";
                break;
            case "=":
                solve();
                break;
            case "%":
                input+="%";
                double d = Double.parseDouble(inputText.getText().toString())/100;
                outputText.setText(String.valueOf(d));
                break;
            default:
                if(input == null){
                    input = "";
                }
                if(data.equals("+") || data.equals("/") || data.equals("-")){
                    solve();
                }
                input += data;
        }
        inputText.setText(input);
    }

    private void solve(){

        if(input.split("\\+").length == 2){
            String numbers[] = input.split("\\+");
            try{
                double d = Double.parseDouble(numbers[0]) + Double.parseDouble(numbers[1]);
                output = Double.toString(d);
                result = cutDecimal(output);
                outputText.setText(result);
                input = d + "";
            } catch (Exception e){
                outputText.setError(e.getMessage().toString());
            }
        }

        if(input.split("\\*").length == 2){
            String numbers[] = input.split("\\*");
            try{
                double d = Double.parseDouble(numbers[0]) * Double.parseDouble(numbers[1]);
                output = Double.toString(d);
                result = cutDecimal(output);
                outputText.setText(result);
                input = d + "";
            } catch (Exception e){
                outputText.setError(e.getMessage().toString());
            }
        }

        if(input.split("\\/").length == 2){
            String numbers[] = input.split("\\/");
            try{
                double d = Double.parseDouble(numbers[0]) / Double.parseDouble(numbers[1]);
                output = Double.toString(d);
                result = cutDecimal(output);
                outputText.setText(result);
                input = d + "";
            } catch (Exception e){
                outputText.setError(e.getMessage().toString());
            }
        }

        if(input.split("\\^").length == 2){
            String numbers[] = input.split("\\^");
            try{
                double d = Math.pow(Double.parseDouble(numbers[0]), Double.parseDouble(numbers[1]));
                output = Double.toString(d);
                result = cutDecimal(output);
                outputText.setText(result);
                input = d + "";
            } catch (Exception e){
                outputText.setError(e.getMessage().toString());
            }
        }

        if(input.split("\\-").length == 2){
            String numbers[] = input.split("\\-");
            try{
                double d = Double.parseDouble(numbers[0]) - Double.parseDouble(numbers[1]);
                output = Double.toString(d);
                result = cutDecimal(output);
                outputText.setText(result);
                input = d + "";
            } catch (Exception e){
                outputText.setError(e.getMessage().toString());
            }
        }

    }

    private String cutDecimal(String number){
        String n [] = number.split("\\.");
        if(n.length >1){
            if(n[1].equals("0")){
                number = n[0];
            }
        }
        return number;
    }
}